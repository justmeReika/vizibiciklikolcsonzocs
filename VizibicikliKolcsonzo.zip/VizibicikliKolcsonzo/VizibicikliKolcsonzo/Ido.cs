﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VizibicikliKolcsonzo
{
    internal class Ido
    {
        public Ido(string nev, DateTime be, DateTime ki)
        {
            this.nev = nev;
            this.be = be;
            this.ki = ki;
        }

        public string nev { get; set; }
        public DateTime be { get; set; }
        public DateTime ki { get; set; }
    }
}
