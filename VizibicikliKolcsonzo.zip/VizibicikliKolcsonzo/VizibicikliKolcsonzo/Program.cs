﻿using VizibicikliKolcsonzo;

List<Kolcsonzes> lista = new List<Kolcsonzes>();
List<Ido> idoLista = new List<Ido>();
Dictionary<string, int> dict = new Dictionary<string, int>();
Console.WriteLine("F4");
beolvas();
Console.WriteLine("beolvasva");
Console.WriteLine("F5");
f5();
Console.WriteLine("F6");
f6();
Console.WriteLine("F7");
f7();
Console.WriteLine("F8");
f8();
Console.WriteLine("F9");
f9();
Console.WriteLine("F10");
f10();

void f10()
{
    int a = 0;
    int b = 0;
    int c = 0;
    int d = 0;
    int e = 0;
    int f = 0;
    int g = 0;

    foreach (var item in lista)
    {
        if (item.jarmuAzonosito.Equals("A"))
        {
            a++;
        }
        else if (item.jarmuAzonosito.Equals("B"))
        {
            b++;
        }
        else if (item.jarmuAzonosito.Equals("C"))
        {
            c++;
        }
        else if (item.jarmuAzonosito.Equals("D"))
        {
            d++;
        }
        else if (item.jarmuAzonosito.Equals("E"))
        {
            e++;
        }
        else if (item.jarmuAzonosito.Equals("F"))
        {
            f++;
        }
        else if (item.jarmuAzonosito.Equals("G"))
        {
            g++;
        }
    }

    Console.WriteLine("A - " + a);
    Console.WriteLine("B - " + b);
    Console.WriteLine("C - " + c);
    Console.WriteLine("D - " + d);
    Console.WriteLine("E - " + e);
    Console.WriteLine("F - " + f);
    Console.WriteLine("G - " + g);

}

void f9()
{
    
    using (StreamWriter sw = new StreamWriter("F.txt")) 
    { 
        foreach (var item in lista)
        {

            if (item.jarmuAzonosito.Equals("F"))
            {
                sw.WriteLine($"neve: {item.nev}  {item.elvitelOra}:{item.elvitelPerc} - {item.visszahozatalOra}:{item.visszahozatalPerce}");
            }
        }
    }
    Console.WriteLine("kiirva");
}

void f8()
{
    int result = 0;
    

    foreach (var item in lista)
    {
        
         result += (int)Math.Ceiling((decimal)(((item.visszahozatalOra * 60) + item.visszahozatalPerce) - (item.elvitelOra * 60 + item.elvitelPerc)) / 30) * 2400;
        
    }
    
    Console.WriteLine("A napi bevétel: "+ result +" Ft");
}

void f7()
{
    Console.WriteLine("Adj meg egy időpontot:");
    string ido = Console.ReadLine();
    DateTime idoszam = DateTime.Parse(ido);

    foreach (var item in lista)
    {
        idoLista.Add(new Ido(item.nev, DateTime.Parse($"{item.elvitelOra}:{item.elvitelPerc}"), DateTime.Parse($"{item.visszahozatalOra}:{item.visszahozatalPerce}")));
    }

    foreach (var item in idoLista)
    {
        if (idoszam>=item.be && idoszam<=item.ki)
        {
            Console.WriteLine($"neve:{item.nev} be:{item.be} ki:{item.ki}");
        }
    }
}

void f6()
{
    Console.WriteLine("Adj meg egy nevet:");
    string nev = Console.ReadLine();
    int count=0;
    foreach (var item in lista)
    {
        if (item.nev.Equals(nev))
        {
            if (count<1)
            {
                Console.WriteLine($"{item.nev} kölcsönzései");
            }
            Console.WriteLine($"{item.elvitelOra}:{item.elvitelPerc} - {item.visszahozatalOra}:{item.visszahozatalPerce}");
            count++;
        }
        
    }
    if (count==0)
    {
        Console.WriteLine("nincs találat!");
    }
}

void f5()
{
    Console.WriteLine("Napi kölcsönzések száma: "+lista.Count);
}

void beolvas()
{
    try
    {
        var f = File.ReadAllLines("kolcsonzesek.txt");
        foreach (var item in f.Skip(1))
        {
            string[] tomb = item.Split(';');
            lista.Add(new Kolcsonzes(tomb[0], tomb[1],int.Parse(tomb[2]),int.Parse(tomb[3]), int.Parse(tomb[4]), int.Parse(tomb[5])));
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine("Hiba: "+ ex);
        
    }
    

}