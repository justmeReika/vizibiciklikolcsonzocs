﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VizibicikliKolcsonzo
{
    internal class Kolcsonzes
    {
        public Kolcsonzes(string nev, string jarmuAzonosito, int elvitelOra, int elvitelPerc, int visszahozatalOra, int visszahozatalPerce)
        {
            this.nev = nev;
            this.jarmuAzonosito = jarmuAzonosito;
            this.elvitelOra = elvitelOra;
            this.elvitelPerc = elvitelPerc;
            this.visszahozatalOra = visszahozatalOra;
            this.visszahozatalPerce = visszahozatalPerce;
        }

        public string nev { get; set; }
        public string jarmuAzonosito { get; set; }
        public int elvitelOra { get; set; }
        public int elvitelPerc { get; set; }
        public int visszahozatalOra { get; set; }
        public int visszahozatalPerce { get; set; }
    }
}
